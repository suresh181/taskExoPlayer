package com.example.task.utilts.exoPlayer

data class viewDetails(var title:String,var descr:String,var image:String,var isClickabe:String) {
}