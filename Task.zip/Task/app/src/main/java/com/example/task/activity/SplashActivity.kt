package com.example.task.activity

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity
import com.example.task.R
import java.util.*

class SplashActivity : AppCompatActivity() {
    lateinit var notificationChannel: NotificationChannel
    lateinit var notificationManager: NotificationManager
    lateinit var builder: Notification.Builder
    private val channelId = "12345"
    private val description = "Opening Task Activity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as
                NotificationManager
        val timer = Timer()
        timer.schedule(object : TimerTask() {
            override fun run() {
                // Notification Title and Message
                Notification()
            }
        }, 0)
        callNextActivity()
    }

    private fun callNextActivity() {
        Handler().postDelayed({
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
        }, 3000)
    }

    private fun Notification(){
        val intent = Intent(this, SplashActivity::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)
            notificationChannel = NotificationChannel(channelId, description, NotificationManager .IMPORTANCE_LOW)
            notificationChannel.lightColor = Color.BLUE
            notificationChannel!!.enableVibration(true)
            notificationManager.createNotificationChannel(notificationChannel)
            builder = Notification.Builder(this, channelId).setContentTitle("NOTIFICATION " +
                    "Starting").setContentText("Opening Task Activity").setSmallIcon(R.drawable.ic_launcher_foreground).setLargeIcon(
                BitmapFactory.decodeResource(this.resources, R.drawable
                .ic_launcher_background))
            builder.setAutoCancel(true)
        }
        notificationManager.notify(12345, builder.build())
    }

    override fun onStart() {
        super.onStart()
    }
    }
