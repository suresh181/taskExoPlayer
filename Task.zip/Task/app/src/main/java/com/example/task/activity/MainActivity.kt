package com.example.task.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.PorterDuff
import android.os.Bundle
import android.os.Handler
import android.view.MotionEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.task.R
import com.example.task.databinding.ActivityMainBinding
import com.example.task.english.EnglishActivity
import com.example.task.hindi.HindiActivity
import com.example.task.tamil.TamilActivity
import com.example.task.utilts.sharedperference.SharedPreferenceHelper


class MainActivity : AppCompatActivity() {
    lateinit var sharedPreferences: SharedPreferences
    lateinit var editor: SharedPreferences.Editor
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        init()

        if (getButton() =="English"){
            startEnglish()
            finish()
        }else if (getButton() =="Tamil"){
            startTamil()
            finish()
        }else if (getButton() == "Hindi"){
            startHindi()
            finish()
        }


    }


    @SuppressLint("UseCompatLoadingForDrawables", "ClickableViewAccessibility")
    fun init(){
        binding.btnEnglish.setOnClickListener{

            saveButton("English")
            startEnglish()

        }
        binding.btnTamil.setOnClickListener {
            binding.btnTamil.background = resources.getDrawable(R.drawable.item_selected)

            saveButton("Tamil")
            startTamil()
        }
        binding.btnHindi.setOnClickListener {
            binding.btnHindi.background = resources.getDrawable(R.drawable.item_selected)

            saveButton("Hindi")
            startHindi()

        }
    }

    private fun saveButton(name:String){
        val sharedPreferenceHelper = SharedPreferenceHelper.getInstance(this)
        sharedPreferenceHelper.add("name",name)
    }
    private fun getButton():String?{
        val sharedPreferenceHelper = SharedPreferenceHelper.getInstance(this)
        return sharedPreferenceHelper.get("name")

    }

    fun startEnglish(){
        Handler().postDelayed({
            binding.btnEnglish.setBackgroundResource(R.drawable.button_background)
            val intent = Intent(this, EnglishActivity::class.java)
            intent.putExtra("ENGLISH","English Post")
            startActivity(intent)
            finish()
        },2000)

    }
    fun startTamil(){
        Handler().postDelayed({
            binding.btnTamil.background = resources.getDrawable(R.drawable.item_selected)
            val intent = Intent(this, TamilActivity::class.java)
            intent.putExtra("TAMIL","Tamil Post")
            startActivity(intent)
            finish()
        },2000)

    }
    fun startHindi(){
        Handler().postDelayed({val intent = Intent(this, HindiActivity::class.java)
            binding.btnHindi.setBackgroundResource(R.drawable.item_selected)
            intent.putExtra("HINDI","Hindi Post")
            startActivity(intent)
            finish()},2000)

    }
    @SuppressLint("ClickableViewAccessibility")
    fun buttonEffect(button: View) {
        button.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    v.background.setColorFilter(-0x1f0b8adf, PorterDuff.Mode.SRC_ATOP)
                    v.invalidate()
                }
                MotionEvent.ACTION_UP -> {
                    v.background.clearColorFilter()
                    v.invalidate()
                }
            }
            false
        }
    }


}